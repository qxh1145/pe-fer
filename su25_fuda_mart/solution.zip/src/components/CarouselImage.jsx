
import Image from "react-bootstrap/Image";

const CarouselImage = ({ text }) => {
  // Sử dụng ảnh placeholder. Bạn có thể thay đổi kích thước nếu cần.
  return (
    <Image src="https://via.placeholder.com/800x400" alt={text} fluid />
  );
};

export default CarouselImage;