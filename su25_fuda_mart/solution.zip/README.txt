step: 

1: npm i
2: npm run server
3: open new terminal => npm start 
